def sum1(a,b):
  c = a+b
  return c

def mul1(a,b):
  c = a*b
  return c