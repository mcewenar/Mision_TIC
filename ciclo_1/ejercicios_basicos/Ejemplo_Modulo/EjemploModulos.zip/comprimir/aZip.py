def crear_zip(archivo):
  print('creando...' + archivo + '.zip')