def crear_tar(archivo):
  print('creando...' + archivo + '.tar')