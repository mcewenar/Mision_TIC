import view.MasterWindows;

public class App {
	public static void main(String[] args) {
            new MasterWindows().setVisible(true);
	}
}
