/*CREATE database dbs_reto5;*/
/*DROP TABLE tbl_escuela;*/
/*DROP DATABASE Escuela;*/
USE dbs_reto5;
SELECT * FROM tbl_escuela;
/*CREATE TABLE tbl_escuela(
	id int NOT NULL PRIMARY KEY,
	nombre varchar(40) NOT NULL, 
	habilidad varchar(40) NOT NULL, 
	anios_servicio int NOT NULL, 
	creador varchar(20) NOT NULL,
	fecha_inicio date NOT NULL
);*/

